-- Migration: Analytics Tables for CADReport
-- Created: 2025-01-04
-- Purpose: Support natural language queries, saved queries, rate limiting, and outlier tracking

-- ============================================================================
-- 1. TENANT QUERY USAGE (Rate Limiting)
-- ============================================================================
CREATE TABLE IF NOT EXISTS tenant_query_usage (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    usage_date DATE NOT NULL DEFAULT CURRENT_DATE,
    query_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(tenant_id, usage_date)
);

CREATE INDEX IF NOT EXISTS idx_tenant_query_usage_lookup 
ON tenant_query_usage(tenant_id, usage_date);

-- ============================================================================
-- 2. SAVED QUERIES (Reusable query templates)
-- ============================================================================
CREATE TABLE IF NOT EXISTS saved_queries (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    natural_language TEXT NOT NULL,           -- Original question asked
    generated_sql TEXT NOT NULL,              -- SQL that Claude generated
    parameters JSONB DEFAULT '{}',            -- Any parameters for the query
    result_type VARCHAR(50) DEFAULT 'table',  -- table, chart, single_value
    chart_config JSONB,                       -- Chart settings if result_type is chart
    created_by INTEGER REFERENCES personnel(id),
    is_shared BOOLEAN DEFAULT FALSE,          -- Available to all tenant users
    is_system BOOLEAN DEFAULT FALSE,          -- Pre-built system query
    use_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_saved_queries_tenant ON saved_queries(tenant_id);
CREATE INDEX IF NOT EXISTS idx_saved_queries_shared ON saved_queries(tenant_id, is_shared);
CREATE INDEX IF NOT EXISTS idx_saved_queries_system ON saved_queries(is_system);

-- ============================================================================
-- 3. QUERY EXECUTION LOG (Audit trail & analytics)
-- ============================================================================
CREATE TABLE IF NOT EXISTS query_execution_log (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    personnel_id INTEGER REFERENCES personnel(id),
    query_type VARCHAR(50) NOT NULL,          -- 'natural_language', 'saved', 'system'
    natural_language TEXT,
    generated_sql TEXT,
    saved_query_id INTEGER REFERENCES saved_queries(id),
    execution_time_ms INTEGER,
    row_count INTEGER,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    api_tokens_used INTEGER,                  -- Track Claude API usage
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_query_log_tenant_date 
ON query_execution_log(tenant_id, created_at DESC);

-- ============================================================================
-- 4. DATA QUALITY ISSUES (Outlier/error tracking)
-- ============================================================================
CREATE TABLE IF NOT EXISTS data_quality_issues (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    incident_id INTEGER REFERENCES incidents(id) ON DELETE CASCADE,
    issue_type VARCHAR(100) NOT NULL,         -- 'response_time_outlier', 'invalid_sequence', etc.
    severity VARCHAR(20) DEFAULT 'warning',   -- 'info', 'warning', 'error'
    field_name VARCHAR(100),
    current_value TEXT,
    expected_range TEXT,
    description TEXT NOT NULL,
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by INTEGER REFERENCES personnel(id),
    resolution_notes TEXT,
    auto_detected BOOLEAN DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_data_quality_tenant 
ON data_quality_issues(tenant_id, resolved_at NULLS FIRST);
CREATE INDEX IF NOT EXISTS idx_data_quality_incident 
ON data_quality_issues(incident_id);

-- ============================================================================
-- 5. ANALYTICS CACHE (Pre-computed stats for dashboard)
-- ============================================================================
CREATE TABLE IF NOT EXISTS analytics_cache (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    cache_key VARCHAR(255) NOT NULL,          -- e.g., 'monthly_stats_2025_01'
    cache_data JSONB NOT NULL,
    computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(tenant_id, cache_key)
);

CREATE INDEX IF NOT EXISTS idx_analytics_cache_lookup 
ON analytics_cache(tenant_id, cache_key);

-- ============================================================================
-- 6. INSERT SYSTEM (PRE-BUILT) QUERIES
-- ============================================================================
INSERT INTO saved_queries (tenant_id, name, description, natural_language, generated_sql, result_type, chart_config, is_system, is_shared)
VALUES 
-- Incident Volume Queries
('_system', 'Incidents by Day of Week', 'Shows which days have the most incidents', 
 'How many incidents occur on each day of the week?',
 $$SELECT 
    CASE EXTRACT(dow FROM alarm_datetime)
        WHEN 0 THEN 'Sunday'
        WHEN 1 THEN 'Monday'
        WHEN 2 THEN 'Tuesday'
        WHEN 3 THEN 'Wednesday'
        WHEN 4 THEN 'Thursday'
        WHEN 5 THEN 'Friday'
        WHEN 6 THEN 'Saturday'
    END as day_name,
    EXTRACT(dow FROM alarm_datetime) as day_order,
    COUNT(*) as incident_count
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY EXTRACT(dow FROM alarm_datetime)
ORDER BY day_order$$,
 'chart', '{"type": "bar", "xField": "day_name", "yField": "incident_count", "title": "Incidents by Day of Week"}', 
 TRUE, TRUE),

('_system', 'Incidents by Hour', 'Shows peak hours for incidents',
 'What hours of the day are busiest for incidents?',
 $$SELECT 
    EXTRACT(hour FROM alarm_datetime) as hour,
    TO_CHAR(alarm_datetime, 'HH12 AM') as hour_label,
    COUNT(*) as incident_count
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY EXTRACT(hour FROM alarm_datetime), TO_CHAR(alarm_datetime, 'HH12 AM')
ORDER BY hour$$,
 'chart', '{"type": "line", "xField": "hour_label", "yField": "incident_count", "title": "Incidents by Hour of Day"}',
 TRUE, TRUE),

('_system', 'Monthly Incident Trend', 'Month-over-month incident volume',
 'Show me monthly incident counts over time',
 $$SELECT 
    DATE_TRUNC('month', alarm_datetime) as month,
    TO_CHAR(alarm_datetime, 'Mon YYYY') as month_label,
    COUNT(*) as incident_count
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY DATE_TRUNC('month', alarm_datetime), TO_CHAR(alarm_datetime, 'Mon YYYY')
ORDER BY month$$,
 'chart', '{"type": "line", "xField": "month_label", "yField": "incident_count", "title": "Monthly Incident Trend"}',
 TRUE, TRUE),

('_system', 'Incidents by Type', 'Breakdown by incident type',
 'What types of incidents do we respond to most?',
 $$SELECT 
    COALESCE(incident_type, 'Unknown') as incident_type,
    COUNT(*) as incident_count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) as percentage
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY incident_type
ORDER BY incident_count DESC
LIMIT 15$$,
 'chart', '{"type": "pie", "labelField": "incident_type", "valueField": "incident_count", "title": "Incidents by Type"}',
 TRUE, TRUE),

-- Response Time Queries
('_system', 'Average Response Times by Unit', 'Compare unit response performance',
 'What are the average response times for each unit?',
 $$SELECT 
    a.unit_designator,
    a.name as unit_name,
    COUNT(iu.id) as response_count,
    ROUND(AVG(EXTRACT(EPOCH FROM (iu.enroute_datetime - iu.dispatch_datetime))/60)::numeric, 1) as avg_turnout_mins,
    ROUND(AVG(EXTRACT(EPOCH FROM (iu.arrived_datetime - iu.enroute_datetime))/60)::numeric, 1) as avg_travel_mins,
    ROUND(AVG(EXTRACT(EPOCH FROM (iu.arrived_datetime - iu.dispatch_datetime))/60)::numeric, 1) as avg_total_response_mins
FROM incident_units iu
JOIN apparatus a ON iu.apparatus_id = a.id
JOIN incidents i ON iu.incident_id = i.id
WHERE i.tenant_id = :tenant_id
    AND i.alarm_datetime >= :start_date 
    AND i.alarm_datetime < :end_date
    AND iu.arrived_datetime IS NOT NULL
    AND a.counts_for_response_times = TRUE
GROUP BY a.unit_designator, a.name
HAVING COUNT(iu.id) >= 5
ORDER BY avg_total_response_mins$$,
 'table', NULL,
 TRUE, TRUE),

('_system', 'Response Time Trend', 'Track response times over time',
 'How have our response times changed over time?',
 $$SELECT 
    DATE_TRUNC('month', i.alarm_datetime) as month,
    TO_CHAR(i.alarm_datetime, 'Mon YYYY') as month_label,
    ROUND(AVG(EXTRACT(EPOCH FROM (iu.arrived_datetime - i.alarm_datetime))/60)::numeric, 1) as avg_response_mins,
    COUNT(DISTINCT i.id) as incident_count
FROM incidents i
JOIN incident_units iu ON i.id = iu.incident_id
JOIN apparatus a ON iu.apparatus_id = a.id
WHERE i.tenant_id = :tenant_id
    AND i.alarm_datetime >= :start_date 
    AND i.alarm_datetime < :end_date
    AND iu.arrived_datetime IS NOT NULL
    AND a.counts_for_response_times = TRUE
GROUP BY DATE_TRUNC('month', i.alarm_datetime), TO_CHAR(i.alarm_datetime, 'Mon YYYY')
ORDER BY month$$,
 'chart', '{"type": "line", "xField": "month_label", "yField": "avg_response_mins", "title": "Average Response Time Trend"}',
 TRUE, TRUE),

-- Unit Activity Queries
('_system', 'Unit Response Count', 'Which units respond most frequently',
 'How many times has each unit responded?',
 $$SELECT 
    a.unit_designator,
    a.name as unit_name,
    a.unit_category,
    COUNT(iu.id) as response_count,
    COUNT(DISTINCT i.id) as unique_incidents
FROM apparatus a
LEFT JOIN incident_units iu ON a.id = iu.apparatus_id
LEFT JOIN incidents i ON iu.incident_id = i.id 
    AND i.alarm_datetime >= :start_date 
    AND i.alarm_datetime < :end_date
WHERE a.tenant_id = :tenant_id
    AND a.active = TRUE
GROUP BY a.id, a.unit_designator, a.name, a.unit_category
ORDER BY response_count DESC$$,
 'chart', '{"type": "bar", "xField": "unit_designator", "yField": "response_count", "title": "Responses by Unit"}',
 TRUE, TRUE),

-- Geographic/Assignment Queries  
('_system', 'Incidents by Municipality', 'Where are incidents occurring?',
 'Which municipalities have the most incidents?',
 $$SELECT 
    COALESCE(municipality, 'Unknown') as municipality,
    COUNT(*) as incident_count,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) as percentage
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY municipality
ORDER BY incident_count DESC$$,
 'chart', '{"type": "pie", "labelField": "municipality", "valueField": "incident_count", "title": "Incidents by Municipality"}',
 TRUE, TRUE),

('_system', 'Mutual Aid Given vs Received', 'Track mutual aid balance',
 'How much mutual aid do we give versus receive?',
 $$SELECT 
    CASE 
        WHEN aid_given THEN 'Aid Given'
        WHEN aid_received THEN 'Aid Received'
        ELSE 'Local Response'
    END as aid_type,
    COUNT(*) as incident_count
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY aid_given, aid_received
ORDER BY incident_count DESC$$,
 'chart', '{"type": "pie", "labelField": "aid_type", "valueField": "incident_count", "title": "Mutual Aid Distribution"}',
 TRUE, TRUE),

-- Year over Year
('_system', 'Year over Year Comparison', 'Compare this year to previous years',
 'Compare incident counts year over year',
 $$SELECT 
    EXTRACT(year FROM alarm_datetime) as year,
    EXTRACT(month FROM alarm_datetime) as month_num,
    TO_CHAR(alarm_datetime, 'Mon') as month_name,
    COUNT(*) as incident_count
FROM incidents 
WHERE tenant_id = :tenant_id
    AND alarm_datetime >= :start_date 
    AND alarm_datetime < :end_date
GROUP BY EXTRACT(year FROM alarm_datetime), EXTRACT(month FROM alarm_datetime), TO_CHAR(alarm_datetime, 'Mon')
ORDER BY year, month_num$$,
 'chart', '{"type": "multiLine", "xField": "month_name", "yField": "incident_count", "seriesField": "year", "title": "Year over Year Comparison"}',
 TRUE, TRUE),

-- Personnel Queries
('_system', 'Personnel Response Counts', 'Who responds most frequently?',
 'How many incidents has each member responded to?',
 $$SELECT 
    p.first_name || ' ' || p.last_name as member_name,
    r.rank_name,
    COUNT(ip.id) as response_count
FROM personnel p
LEFT JOIN ranks r ON p.rank_id = r.id
LEFT JOIN incident_personnel ip ON p.id = ip.personnel_id
LEFT JOIN incidents i ON ip.incident_id = i.id
    AND i.alarm_datetime >= :start_date 
    AND i.alarm_datetime < :end_date
WHERE p.tenant_id = :tenant_id
    AND p.active = TRUE
GROUP BY p.id, p.first_name, p.last_name, r.rank_name
ORDER BY response_count DESC$$,
 'table', NULL,
 TRUE, TRUE)

ON CONFLICT DO NOTHING;

-- ============================================================================
-- 7. HELPER FUNCTION: Reset daily query counts (run via cron)
-- ============================================================================
CREATE OR REPLACE FUNCTION reset_daily_query_counts()
RETURNS void AS $$
BEGIN
    -- Old records auto-expire, this just ensures clean state
    DELETE FROM tenant_query_usage 
    WHERE usage_date < CURRENT_DATE - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- 8. UPDATE TRIGGER FOR updated_at
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_tenant_query_usage_updated_at ON tenant_query_usage;
CREATE TRIGGER update_tenant_query_usage_updated_at
    BEFORE UPDATE ON tenant_query_usage
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_saved_queries_updated_at ON saved_queries;
CREATE TRIGGER update_saved_queries_updated_at
    BEFORE UPDATE ON saved_queries
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Done!
SELECT 'Analytics tables migration complete' as status;
