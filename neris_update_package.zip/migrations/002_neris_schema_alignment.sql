-- ============================================================================
-- RunSheet NERIS Schema Alignment Migration
-- Complete rebuild for 100% NERIS compatibility
-- 
-- Run: psql -d runsheet_db -f 002_neris_schema_alignment.sql
-- ============================================================================

BEGIN;

-- ============================================================================
-- STEP 1: Backup info (informational only)
-- ============================================================================
DO $$
DECLARE
    incident_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO incident_count FROM incidents WHERE deleted_at IS NULL;
    RAISE NOTICE 'Starting NERIS migration. Current incidents: %', incident_count;
    
    IF incident_count > 0 THEN
        RAISE NOTICE 'WARNING: You have existing incidents. Review data after migration.';
    END IF;
END $$;

-- ============================================================================
-- STEP 2: Add NERIS ID column
-- ============================================================================
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_id TEXT UNIQUE;
CREATE INDEX IF NOT EXISTS idx_incidents_neris_id ON incidents(neris_id);

-- ============================================================================
-- STEP 3: Add new TEXT-based NERIS classification columns
-- These store exact values expected by NERIS API
-- ============================================================================

-- Incident types - hierarchical TEXT array
-- Example: ["FIRE: STRUCTURE_FIRE: RESIDENTIAL_SINGLE"]
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_incident_type_codes TEXT[];

-- Primary type flags (parallel array)
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_incident_type_primary BOOLEAN[];

-- Location use as full JSONB module
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_location_use JSONB;

-- Actions taken - TEXT array
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_action_codes TEXT[];

-- No action reason code
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_noaction_code TEXT;

-- ============================================================================
-- STEP 4: Add mutual aid fields
-- ============================================================================
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_aid_direction TEXT;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_aid_type TEXT;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_aid_departments TEXT[];

-- ============================================================================
-- STEP 5: Add structured location fields
-- ============================================================================
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_location JSONB;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS latitude TEXT;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS longitude TEXT;

-- ============================================================================
-- STEP 6: Add all NERIS tactic timestamps
-- ============================================================================
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_command_established TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_sizeup_completed TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_primary_search_begin TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_primary_search_complete TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_water_on_fire TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_fire_knocked_down TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS time_suppression_complete TIMESTAMP WITH TIME ZONE;
-- time_fire_under_control and time_extrication_complete already exist

-- ============================================================================
-- STEP 7: Add people present field
-- ============================================================================
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_people_present BOOLEAN;

-- ============================================================================
-- STEP 8: Add review workflow fields
-- ============================================================================
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS review_status TEXT DEFAULT 'pending';
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS reviewed_by INTEGER REFERENCES personnel(id);
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS neris_last_validated_at TIMESTAMP WITH TIME ZONE;

-- ============================================================================
-- STEP 9: Add apparatus NERIS unit type
-- ============================================================================
ALTER TABLE apparatus ADD COLUMN IF NOT EXISTS neris_unit_type TEXT;

-- ============================================================================
-- STEP 10: Update incident_units table for NERIS compatibility
-- ============================================================================
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS neris_unit_id_linked TEXT;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS neris_unit_id_reported TEXT;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS response_mode TEXT;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS is_mutual_aid BOOLEAN DEFAULT FALSE;

-- Rename time columns to match NERIS exactly (if old names exist)
DO $$
BEGIN
    -- Check and rename if needed
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'incident_units' AND column_name = 'time_dispatched') THEN
        ALTER TABLE incident_units RENAME COLUMN time_dispatched TO time_dispatch;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'incident_units' AND column_name = 'time_enroute') THEN
        ALTER TABLE incident_units RENAME COLUMN time_enroute TO time_enroute_to_scene;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'incident_units' AND column_name = 'time_on_scene') THEN
        -- Already correct name, skip
        NULL;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'incident_units' AND column_name = 'time_cleared') THEN
        ALTER TABLE incident_units RENAME COLUMN time_cleared TO time_unit_clear;
    END IF;
EXCEPTION WHEN others THEN
    RAISE NOTICE 'Column rename skipped (may already be correct): %', SQLERRM;
END $$;

-- Add additional EMS time columns
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS time_canceled_enroute TIMESTAMP WITH TIME ZONE;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS time_staging TIMESTAMP WITH TIME ZONE;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS time_at_patient TIMESTAMP WITH TIME ZONE;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS time_enroute_hospital TIMESTAMP WITH TIME ZONE;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS time_arrived_hospital TIMESTAMP WITH TIME ZONE;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS time_hospital_clear TIMESTAMP WITH TIME ZONE;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS hospital_destination TEXT;
ALTER TABLE incident_units ADD COLUMN IF NOT EXISTS transport_mode TEXT;

-- ============================================================================
-- STEP 11: Add NERIS settings
-- ============================================================================
INSERT INTO settings (category, key, value, value_type, description)
VALUES 
    ('neris', 'fd_neris_id', '', 'string', 'Fire Department NERIS ID (e.g., FD24027000). Get from NERIS registration.'),
    ('neris', 'fd_name', 'Glen Moore Fire Company', 'string', 'Fire Department official name'),
    ('neris', 'auto_generate_neris_id', 'true', 'boolean', 'Auto-generate incident NERIS IDs'),
    ('neris', 'api_endpoint', 'https://api.neris.usfa.fema.gov/v1', 'string', 'NERIS API endpoint'),
    ('neris', 'submission_enabled', 'false', 'boolean', 'Enable NERIS API submission')
ON CONFLICT (category, key) DO UPDATE SET description = EXCLUDED.description;

-- ============================================================================
-- STEP 12: Create function to generate NERIS ID
-- ============================================================================
CREATE OR REPLACE FUNCTION generate_neris_id(
    p_fd_neris_id TEXT,
    p_incident_time TIMESTAMP WITH TIME ZONE
) RETURNS TEXT AS $$
BEGIN
    IF p_fd_neris_id IS NULL OR p_fd_neris_id = '' THEN
        RETURN NULL;
    END IF;
    RETURN p_fd_neris_id || ':' || 
           (EXTRACT(EPOCH FROM COALESCE(p_incident_time, NOW())) * 1000)::BIGINT::TEXT;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- STEP 13: Create function to validate NERIS code exists
-- ============================================================================
CREATE OR REPLACE FUNCTION validate_neris_code(
    p_category TEXT,
    p_code TEXT
) RETURNS BOOLEAN AS $$
DECLARE
    code_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1 FROM neris_codes 
        WHERE category = p_category AND value = p_code AND active = true
    ) INTO code_exists;
    RETURN code_exists;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- STEP 14: Drop old integer NERIS columns (only if empty)
-- ============================================================================
DO $$
DECLARE
    has_int_data BOOLEAN;
BEGIN
    -- Check if any incidents have data in the old integer columns
    SELECT EXISTS (
        SELECT 1 FROM incidents 
        WHERE neris_incident_types IS NOT NULL 
           OR neris_property_use IS NOT NULL 
           OR neris_actions_taken IS NOT NULL
    ) INTO has_int_data;
    
    IF has_int_data THEN
        RAISE NOTICE 'Old integer NERIS columns have data - NOT dropping them.';
        RAISE NOTICE 'Please migrate data manually, then run:';
        RAISE NOTICE '  ALTER TABLE incidents DROP COLUMN neris_incident_types;';
        RAISE NOTICE '  ALTER TABLE incidents DROP COLUMN neris_property_use;';
        RAISE NOTICE '  ALTER TABLE incidents DROP COLUMN neris_actions_taken;';
    ELSE
        -- Safe to drop
        ALTER TABLE incidents DROP COLUMN IF EXISTS neris_incident_types;
        ALTER TABLE incidents DROP COLUMN IF EXISTS neris_property_use;
        ALTER TABLE incidents DROP COLUMN IF EXISTS neris_actions_taken;
        RAISE NOTICE 'Dropped old integer NERIS columns (were empty)';
    END IF;
END $$;

-- Also drop the old legacy lookup tables if they're empty
DO $$
DECLARE
    has_old_types BOOLEAN;
    has_old_uses BOOLEAN;
    has_old_actions BOOLEAN;
BEGIN
    SELECT EXISTS (SELECT 1 FROM neris_incident_types LIMIT 1) INTO has_old_types;
    SELECT EXISTS (SELECT 1 FROM neris_property_uses LIMIT 1) INTO has_old_uses;
    SELECT EXISTS (SELECT 1 FROM neris_actions_taken LIMIT 1) INTO has_old_actions;
    
    IF NOT has_old_types THEN
        DROP TABLE IF EXISTS neris_incident_types;
        RAISE NOTICE 'Dropped empty neris_incident_types table';
    END IF;
    
    IF NOT has_old_uses THEN
        DROP TABLE IF EXISTS neris_property_uses;
        RAISE NOTICE 'Dropped empty neris_property_uses table';
    END IF;
    
    IF NOT has_old_actions THEN
        DROP TABLE IF EXISTS neris_actions_taken;
        RAISE NOTICE 'Dropped empty neris_actions_taken table';
    END IF;
EXCEPTION WHEN others THEN
    RAISE NOTICE 'Could not drop old tables: %', SQLERRM;
END $$;

-- ============================================================================
-- STEP 15: Create indexes for common queries
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_incidents_year_status ON incidents(year_prefix, status);
CREATE INDEX IF NOT EXISTS idx_incidents_incident_date ON incidents(incident_date);
CREATE INDEX IF NOT EXISTS idx_incidents_review_status ON incidents(review_status);
CREATE INDEX IF NOT EXISTS idx_neris_codes_category ON neris_codes(category);
CREATE INDEX IF NOT EXISTS idx_neris_codes_category_value ON neris_codes(category, value);
CREATE INDEX IF NOT EXISTS idx_neris_codes_value_1 ON neris_codes(value_1);

-- ============================================================================
-- SUMMARY
-- ============================================================================
DO $$
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '============================================================';
    RAISE NOTICE 'NERIS SCHEMA MIGRATION COMPLETE';
    RAISE NOTICE '============================================================';
    RAISE NOTICE '';
    RAISE NOTICE 'Schema is now 100%% NERIS compatible:';
    RAISE NOTICE '  - All NERIS fields use TEXT codes (not integers)';
    RAISE NOTICE '  - Location use stored as JSONB module';
    RAISE NOTICE '  - Unit times match NERIS field names';
    RAISE NOTICE '  - All tactic timestamps available';
    RAISE NOTICE '';
    RAISE NOTICE 'NEXT STEPS:';
    RAISE NOTICE '1. Replace backend/models.py with updated version';
    RAISE NOTICE '2. Replace backend/routers/incidents.py with updated version';
    RAISE NOTICE '3. Import NERIS codes from Excel files (Admin > NERIS Codes)';
    RAISE NOTICE '4. Set fd_neris_id in settings when you register';
    RAISE NOTICE '5. Restart backend: sudo systemctl restart runsheet';
    RAISE NOTICE '============================================================';
END $$;

COMMIT;
